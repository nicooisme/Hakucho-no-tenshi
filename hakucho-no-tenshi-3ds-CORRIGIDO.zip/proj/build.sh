#!/usr/bin/env bash
# Build helper for Hakuchou no Tenshi (白鳥の天使)
# Requires devkitPro: devkitARM + libctru + citro2d/citro3d + tex3ds (+ makerom, bannertool for .cia)
set -e

if [ -z "$DEVKITPRO" ]; then
  echo "ERROR: DEVKITPRO is not set. Install devkitPro and:"
  echo "  export DEVKITPRO=/opt/devkitpro"
  echo "  export DEVKITARM=\$DEVKITPRO/devkitARM"
  echo "  export PATH=\$DEVKITPRO/tools/bin:\$DEVKITARM/bin:\$PATH"
  exit 1
fi
export DEVKITARM="${DEVKITARM:-$DEVKITPRO/devkitARM}"
export PATH="$DEVKITPRO/tools/bin:$DEVKITARM/bin:$PATH"

TARGET="${1:-cia}"   # "3dsx" or "cia"
echo ">> make clean"
make clean
echo ">> make $TARGET"
make "$TARGET"
echo
echo "Done."
ls -lh hakuchou.3dsx hakuchou.cia 2>/dev/null || true
