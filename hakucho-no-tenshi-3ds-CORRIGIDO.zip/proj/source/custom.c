#include "game.h"
#include <stdio.h>

/* cores dos times p/ moldura */
#define ORANGE_R 255
#define ORANGE_G 122
#define ORANGE_B 24

/* numero de skins disponiveis */
#define NUM_SKIN 4

static int cat_count(int cat)
{
    switch (cat) {
        case 0: return NUM_SKIN;
        case 1: return NUM_HAIR;
        case 2: return NUM_CLOTHES;
    }
    return 1;
}

static int *cat_value(Game *g, int cat)
{
    switch (cat) {
        case 0: return &g->selSkin;
        case 1: return &g->selHair;
        case 2: return &g->selCloth;
    }
    return &g->selSkin;
}

void custom_input(Game *g, u32 kDown)
{
    if (kDown & KEY_DOWN) g->selCat = (g->selCat + 1) % 3;
    if (kDown & KEY_UP)   g->selCat = (g->selCat + 2) % 3;

    int n = cat_count(g->selCat);
    int *v = cat_value(g, g->selCat);
    if (kDown & KEY_RIGHT) *v = (*v + 1) % n;
    if (kDown & KEY_LEFT)  *v = (*v + n - 1) % n;

    /* L/R tambem trocam de categoria, p/ conforto */
    if (kDown & KEY_R) g->selCat = (g->selCat + 1) % 3;
    if (kDown & KEY_L) g->selCat = (g->selCat + 2) % 3;
}

static void text(C2D_TextBuf buf, const char *s, float x, float y,
                 float sz, u32 col)
{
    C2D_Text t;
    C2D_TextParse(&t, buf, s);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, 0.5f, sz, sz, col);
}

void draw_custom(Game *g, Assets *a, C3D_RenderTarget *top, C3D_RenderTarget *bot)
{
    /* ---------- TELA DE CIMA: preview centralizado ---------- */
    C2D_SceneBegin(top);
    C2D_TargetClear(top, C2D_Color32(20, 30, 60, 255));

    /* "plataforma" no centro exato da tela de cima */
    float cx = TOP_W * 0.5f;
    float cy = TOP_H * 0.5f;

    /* moldura/aro do time laranja sob os pes */
    C2D_DrawEllipse(cx - 44, cy + 40, 0.0f, 88, 28,
                    C2D_Color32(ORANGE_R, ORANGE_G, ORANGE_B, 90));

    /* preview ampliado (3x), parado em idle, virado p/ direita.
       O centro do sprite e (0.5,0.9): para o personagem ficar
       visualmente centrado, deslocamos a ancora um pouco p/ baixo. */
    float scale = 3.0f;
    float footY = cy + 44.0f;   /* onde ficam os pes */
    draw_character(a, g->selSkin, g->selHair, g->selCloth,
                   false, 0, +1, cx, footY, scale);

    C2D_TextBuf tb = C2D_TextBufNew(64);
    text(tb, "Monte seu personagem", cx - 96, 14, 0.7f,
         C2D_Color32(255, 255, 255, 255));
    C2D_TextBufDelete(tb);

    /* ---------- TELA DE BAIXO: menu ---------- */
    C2D_SceneBegin(bot);
    C2D_TargetClear(bot, C2D_Color32(28, 28, 38, 255));

    C2D_TextBuf b = C2D_TextBufNew(256);
    const char *names[3] = { "Pele", "Cabelo", "Roupa" };
    int vals[3]  = { g->selSkin + 1, g->selHair + 1, g->selCloth + 1 };
    int maxs[3]  = { NUM_SKIN, NUM_HAIR, NUM_CLOTHES };

    for (int i = 0; i < 3; i++) {
        float y = 40 + i * 42;
        bool focus = (g->selCat == i);
        u32 col = focus ? C2D_Color32(255, 220, 120, 255)
                        : C2D_Color32(170, 170, 180, 255);
        /* destaque da linha em foco */
        if (focus)
            C2D_DrawRectSolid(14, y - 6, 0.0f, BOT_W - 28, 34,
                              C2D_Color32(60, 60, 80, 255));

        char line[48];
        snprintf(line, sizeof line, "%s  <  %d / %d  >",
                 names[i], vals[i], maxs[i]);
        text(b, line, 28, y, 0.7f, col);
    }

    text(b, "Cima/Baixo: categoria   Esq/Dir: trocar",
         18, 168, 0.45f, C2D_Color32(150, 150, 160, 255));
    text(b, "START: comecar a partida",
         18, 188, 0.5f, C2D_Color32(120, 230, 140, 255));
    C2D_TextBufDelete(b);
}
