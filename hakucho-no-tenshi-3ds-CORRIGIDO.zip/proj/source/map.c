#include "game.h"
#include <math.h>
#include <stdlib.h>

/* Radial island with sinusoidal noise on the borders. */
void map_generate(Game *g)
{
    const float cx = MAP_W * 0.5f;
    const float cy = MAP_H * 0.5f;
    const float baseR = (MAP_H * 0.5f) - 1.0f;

    /* random phase/amp so each match differs */
    float ph1 = (rand() % 628) / 100.0f;
    float ph2 = (rand() % 628) / 100.0f;
    float a1  = 1.2f + (rand() % 100) / 100.0f;   /* 1.2 .. 2.2 */
    float a2  = 0.6f + (rand() % 80)  / 100.0f;

    for (int ty = 0; ty < MAP_H; ty++) {
        for (int tx = 0; tx < MAP_W; tx++) {
            float dx = (tx + 0.5f - cx);
            float dy = (ty + 0.5f - cy) * (MAP_W / (float)MAP_H); /* aspect correct */
            float dist = sqrtf(dx * dx + dy * dy);
            float ang  = atan2f(dy, dx);
            float wobble = a1 * sinf(ang * 3.0f + ph1) + a2 * sinf(ang * 7.0f + ph2);
            float edge = baseR + wobble;

            if (dist > edge) {
                g->tiles[ty][tx] = T_WATER;
                continue;
            }
            /* land: default grass */
            unsigned char kind = T_GRASS;

            /* upper third becomes snow */
            if (ty < MAP_H / 3)
                kind = T_SNOW;

            /* central stone cross */
            int ccx = MAP_W / 2, ccy = MAP_H / 2;
            if ((abs(tx - ccx) <= 1 && abs(ty - ccy) <= 3) ||
                (abs(ty - ccy) <= 1 && abs(tx - ccx) <= 3))
                kind = T_STONE;

            g->tiles[ty][tx] = kind;
        }
    }

    /* clear paint */
    for (int y = 0; y < PAINT_H; y++)
        for (int x = 0; x < PAINT_W; x++)
            g->paint[y][x] = P_NONE;

    /* Base spawn points: Orange bottom-center, Blue top-center,
       snapped to nearest land. */
    float bxs[2] = { (MAP_W * TILE) * 0.5f, (MAP_W * TILE) * 0.5f };
    float bys[2] = { (MAP_H * TILE) - TILE * 1.5f, TILE * 1.5f };
    for (int t = 0; t < 2; t++) {
        float bx = bxs[t], by = bys[t];
        if (!map_is_land_px(g, bx, by)) {
            /* search outward vertically toward center for land */
            float step = (t == TEAM_ORANGE) ? -TILE : TILE;
            for (int k = 0; k < MAP_H; k++) {
                by += step;
                if (map_is_land_px(g, bx, by)) break;
            }
        }
        g->baseX[t] = bx;
        g->baseY[t] = by;
    }
}

int map_tile_at_px(const Game *g, float px, float py)
{
    int tx = (int)(px / TILE);
    int ty = (int)(py / TILE);
    if (tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H) return T_WATER;
    return g->tiles[ty][tx];
}

bool map_is_land_px(const Game *g, float px, float py)
{
    return map_tile_at_px(g, px, py) != T_WATER;
}

void map_paint_at(Game *g, float px, float py, int owner, float radius)
{
    int cx = (int)(px / PAINT);
    int cy = (int)(py / PAINT);
    int r  = (int)(radius / PAINT) + 1;
    for (int y = cy - r; y <= cy + r; y++) {
        for (int x = cx - r; x <= cx + r; x++) {
            if (x < 0 || y < 0 || x >= PAINT_W || y >= PAINT_H) continue;
            float wx = (x + 0.5f) * PAINT;
            float wy = (y + 0.5f) * PAINT;
            float dx = wx - px, dy = wy - py;
            if (dx * dx + dy * dy > radius * radius) continue;
            if (!map_is_land_px(g, wx, wy)) continue; /* never paint water */
            g->paint[y][x] = (unsigned char)owner;
        }
    }
}

int map_paint_owner_px(const Game *g, float px, float py)
{
    int x = (int)(px / PAINT);
    int y = (int)(py / PAINT);
    if (x < 0 || y < 0 || x >= PAINT_W || y >= PAINT_H) return P_NONE;
    return g->paint[y][x];
}

void map_compute_score(Game *g)
{
    int land = 0, o = 0, b = 0;
    for (int y = 0; y < PAINT_H; y++) {
        for (int x = 0; x < PAINT_W; x++) {
            float wx = (x + 0.5f) * PAINT;
            float wy = (y + 0.5f) * PAINT;
            if (!map_is_land_px(g, wx, wy)) continue;
            land++;
            if (g->paint[y][x] == P_ORANGE) o++;
            else if (g->paint[y][x] == P_BLUE) b++;
        }
    }
    if (land == 0) land = 1;
    g->pctOrange = (o * 100) / land;
    g->pctBlue   = (b * 100) / land;
}
