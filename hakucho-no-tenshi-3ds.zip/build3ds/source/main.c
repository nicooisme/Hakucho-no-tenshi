#include "game.h"
#include <stdlib.h>
#include <string.h>

#include "tiles.h"
#include "chars.h"
#include "hp.h"
#include "hair.h"
#include "roupas.h"

/* ---------------- shared graphics ---------------- */
C2D_SpriteSheet g_tilesSheet;
C2D_SpriteSheet g_charsSheet;
C2D_SpriteSheet g_hpSheet;
C2D_SpriteSheet g_hairSheet;
C2D_SpriteSheet g_roupaSheet;

C2D_Image g_tileImg[4];
C2D_Image g_charIdle[4][8];
C2D_Image g_charWalk[4][2];
C2D_Image g_hpFull;
C2D_Image g_hpEmpty;
C2D_Image g_hairImg[HAIR_COUNT];
C2D_Image g_roupaImg[ROUPA_COUNT];

typedef enum { ST_TITLE, ST_CUSTOMIZE, ST_PLAY, ST_PAUSE, ST_END } GameState;

static Entity s_ents[ENTITY_COUNT];
static float  s_timeLeft;
static int    s_covO, s_covB;
static int    s_hairChoice = 1; /* obrigatório: 1..HAIR_COUNT, nunca 0/"nenhum" */
static int    s_roupaChoice = 1; /* obrigatório: 1..ROUPA_COUNT, nunca 0/"nenhuma" */
static int    s_skinChoice = 0; /* 0..3 -> qual dos 4 tons de pele/personagem */
static GameState s_state = ST_TITLE;

static void load_graphics(void)
{
    g_tilesSheet = C2D_SpriteSheetLoad("romfs:/gfx/tiles.t3x");
    g_charsSheet = C2D_SpriteSheetLoad("romfs:/gfx/chars.t3x");
    g_hpSheet    = C2D_SpriteSheetLoad("romfs:/gfx/hp.t3x");

    g_tileImg[TILE_WATER] = C2D_SpriteSheetGetImage(g_tilesSheet, tiles_water_idx);
    g_tileImg[TILE_GRASS] = C2D_SpriteSheetGetImage(g_tilesSheet, tiles_grass_idx);
    g_tileImg[TILE_STONE] = C2D_SpriteSheetGetImage(g_tilesSheet, tiles_stone_idx);
    g_tileImg[TILE_SNOW]  = C2D_SpriteSheetGetImage(g_tilesSheet, tiles_snow_idx);

    g_charIdle[0][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_idle0_idx);
    g_charIdle[0][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_idle1_idx);
    g_charIdle[0][2] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_idle2_idx);
    g_charIdle[0][3] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_idle3_idx);
    g_charIdle[0][4] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_idle4_idx);
    g_charIdle[0][5] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_idle5_idx);
    g_charIdle[0][6] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_idle6_idx);
    g_charIdle[0][7] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_idle7_idx);
    g_charWalk[0][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_walk0_idx);
    g_charWalk[0][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c0_walk1_idx);

    g_charIdle[1][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_idle0_idx);
    g_charIdle[1][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_idle1_idx);
    g_charIdle[1][2] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_idle2_idx);
    g_charIdle[1][3] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_idle3_idx);
    g_charIdle[1][4] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_idle4_idx);
    g_charIdle[1][5] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_idle5_idx);
    g_charIdle[1][6] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_idle6_idx);
    g_charIdle[1][7] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_idle7_idx);
    g_charWalk[1][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_walk0_idx);
    g_charWalk[1][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c1_walk1_idx);

    g_charIdle[2][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_idle0_idx);
    g_charIdle[2][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_idle1_idx);
    g_charIdle[2][2] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_idle2_idx);
    g_charIdle[2][3] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_idle3_idx);
    g_charIdle[2][4] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_idle4_idx);
    g_charIdle[2][5] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_idle5_idx);
    g_charIdle[2][6] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_idle6_idx);
    g_charIdle[2][7] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_idle7_idx);
    g_charWalk[2][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_walk0_idx);
    g_charWalk[2][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c2_walk1_idx);

    g_charIdle[3][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_idle0_idx);
    g_charIdle[3][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_idle1_idx);
    g_charIdle[3][2] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_idle2_idx);
    g_charIdle[3][3] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_idle3_idx);
    g_charIdle[3][4] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_idle4_idx);
    g_charIdle[3][5] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_idle5_idx);
    g_charIdle[3][6] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_idle6_idx);
    g_charIdle[3][7] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_idle7_idx);
    g_charWalk[3][0] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_walk0_idx);
    g_charWalk[3][1] = C2D_SpriteSheetGetImage(g_charsSheet, chars_c3_walk1_idx);

    g_hpFull  = C2D_SpriteSheetGetImage(g_hpSheet, hp_full_idx);
    g_hpEmpty = C2D_SpriteSheetGetImage(g_hpSheet, hp_empty_idx);

    g_hairSheet = C2D_SpriteSheetLoad("romfs:/gfx/hair.t3x");
    g_hairImg[0] = C2D_SpriteSheetGetImage(g_hairSheet, hair_h1_idx);
    g_hairImg[1] = C2D_SpriteSheetGetImage(g_hairSheet, hair_h2_idx);
    g_hairImg[2] = C2D_SpriteSheetGetImage(g_hairSheet, hair_h3_idx);
    g_hairImg[3] = C2D_SpriteSheetGetImage(g_hairSheet, hair_h4_idx);
    g_hairImg[4] = C2D_SpriteSheetGetImage(g_hairSheet, hair_h5_idx);
    g_hairImg[5] = C2D_SpriteSheetGetImage(g_hairSheet, hair_h6_idx);

    g_roupaSheet = C2D_SpriteSheetLoad("romfs:/gfx/roupas.t3x");
    g_roupaImg[0] = C2D_SpriteSheetGetImage(g_roupaSheet, roupas_r1_idx);
    g_roupaImg[1] = C2D_SpriteSheetGetImage(g_roupaSheet, roupas_r2_idx);
    g_roupaImg[2] = C2D_SpriteSheetGetImage(g_roupaSheet, roupas_r3_idx);
    g_roupaImg[3] = C2D_SpriteSheetGetImage(g_roupaSheet, roupas_r4_idx);
    g_roupaImg[4] = C2D_SpriteSheetGetImage(g_roupaSheet, roupas_r5_idx);

    /* filtro suave (bilinear) só nos personagens/cabelo/roupa -- sem isso,
       qualquer ampliação fica pixelizada/blocuda. Tiles e corações ficam
       no filtro padrão (pixel art proposital). */
    C3D_TexSetFilter(g_charIdle[0][0].tex, GPU_LINEAR, GPU_LINEAR);
    C3D_TexSetFilter(g_hairImg[0].tex, GPU_LINEAR, GPU_LINEAR);
    C3D_TexSetFilter(g_roupaImg[0].tex, GPU_LINEAR, GPU_LINEAR);
}

static void free_graphics(void)
{
    C2D_SpriteSheetFree(g_tilesSheet);
    C2D_SpriteSheetFree(g_charsSheet);
    C2D_SpriteSheetFree(g_hpSheet);
    C2D_SpriteSheetFree(g_hairSheet);
    C2D_SpriteSheetFree(g_roupaSheet);
}

/* player = orange/skin0, ally bot = orange/skin1, two foe bots = blue/skin2,3 */
static void start_match(void)
{
    map_generate();
    entity_init(&s_ents[0], TEAM_ORANGE, s_skinChoice, 1); /* player */
    s_ents[0].hair = s_hairChoice;
    s_ents[0].roupa = s_roupaChoice;
    entity_init(&s_ents[1], TEAM_ORANGE, 1, 0); /* ally bot   */
    entity_init(&s_ents[2], TEAM_BLUE,   2, 0); /* foe bot 1  */
    entity_init(&s_ents[3], TEAM_BLUE,   3, 0); /* foe bot 2  */
    /* bots também usam cabelo -- é o que mostra a cor do time deles agora */
    s_ents[1].hair = 2;
    s_ents[2].hair = 3;
    s_ents[3].hair = 4;
    /* bots mais rápidos que o jogador */
    s_ents[1].speedMul = 1.35f;
    s_ents[2].speedMul = 1.35f;
    s_ents[3].speedMul = 1.35f;

    /* small home splat so the match doesn't start at 0% */
    for (int i = 0; i < ENTITY_COUNT; i++) {
        ink_paint(s_ents[i].x, s_ents[i].y, 18.0f, s_ents[i].team);
    }

    s_timeLeft = MATCH_SECONDS;
    ink_coverage(&s_covO, &s_covB);
    s_state = ST_PLAY;
}

int main(int argc, char *argv[])
{
    gfxInitDefault();
    Result rc = romfsInit();
    if (R_FAILED(rc)) {
        /* romfs failed to mount: nothing we can draw without it, just exit cleanly */
        gfxExit();
        return 0;
    }

    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    C3D_RenderTarget *top    = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget *bottom = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    g_textBuf = C2D_TextBufNew(4096);
    g_kiwiFont = C2D_FontLoad("romfs:/gfx/KiwiSoda.bcfnt"); /* NULL se não existir -- ok, cai pra padrão */
    load_graphics();

    audio_init();
    audio_play_bgm();

    srand((unsigned int)osGetTime());

    u64 lastTick = osGetTime();

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        if (kDown & KEY_START && s_state != ST_PLAY && s_state != ST_PAUSE) {
            start_match();
        }
        if (kDown & KEY_X) {
            if (s_state == ST_PLAY) s_state = ST_PAUSE;
            else if (s_state == ST_PAUSE) s_state = ST_PLAY;
        }
        if (kDown & KEY_SELECT) {
            if (s_state == ST_TITLE) s_state = ST_CUSTOMIZE;
            else if (s_state == ST_CUSTOMIZE) s_state = ST_TITLE;
            else if (s_state == ST_PAUSE) s_state = ST_CUSTOMIZE; /* sai do jogo pra personalização */
        }
        if (s_state == ST_CUSTOMIZE) {
            if (kDown & KEY_A) s_hairChoice  = (s_hairChoice  >= HAIR_COUNT)  ? 1 : s_hairChoice + 1;
            if (kDown & KEY_B) s_skinChoice  = (s_skinChoice  >= 3)           ? 0 : s_skinChoice + 1;
            if (kDown & KEY_Y) s_roupaChoice = (s_roupaChoice >= ROUPA_COUNT) ? 1 : s_roupaChoice + 1;
        }

        u64 now = osGetTime();
        float dt = (now - lastTick) / 1000.0f;
        lastTick = now;
        if (dt > 0.05f) dt = 0.05f;
        if (dt < 0.0f)  dt = 0.0f;

        if (s_state == ST_PLAY) {
            s_timeLeft -= dt;

            entity_update_player(&s_ents[0], dt);
            for (int i = 1; i < ENTITY_COUNT; i++) {
                entity_update_bot(&s_ents[i], s_ents, ENTITY_COUNT, dt);
            }
            for (int i = 0; i < ENTITY_COUNT; i++) {
                entity_tick_status(&s_ents[i], dt);
            }

            ink_coverage(&s_covO, &s_covB);

            if (s_timeLeft <= 0.0f) {
                s_timeLeft = 0.0f;
                s_state = ST_END;
            }
        }

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

        C2D_TargetClear(top, C2D_Color32(8, 18, 30, 255));
        C2D_SceneBegin(top);
        if (s_state == ST_TITLE) {
            render_title(s_hairChoice);
        } else if (s_state == ST_CUSTOMIZE) {
            render_customize(s_hairChoice, s_roupaChoice, s_skinChoice);
        } else if (s_state == ST_PLAY) {
            render_top(s_ents, ENTITY_COUNT);
        } else if (s_state == ST_PAUSE) {
            render_top(s_ents, ENTITY_COUNT); /* jogo congelado */
            render_pause();
        } else { /* ST_END */
            render_top(s_ents, ENTITY_COUNT);
            render_end(s_covO, s_covB);
        }

        C2D_TargetClear(bottom, C2D_Color32(6, 18, 30, 255));
        C2D_SceneBegin(bottom);
        if (s_state == ST_PLAY || s_state == ST_END || s_state == ST_PAUSE) {
            render_bottom(&s_ents[0], s_timeLeft, s_covO, s_covB);
        }

        C3D_FrameEnd(0);
    }

    free_graphics();
    audio_exit();
    if (g_kiwiFont) C2D_FontFree(g_kiwiFont);
    C2D_TextBufDelete(g_textBuf);
    C2D_Fini();
    C3D_Fini();
    romfsExit();
    gfxExit();
    return 0;
}
